package com.cg.traineemanagement.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineemanagement.beans.TraineeBean;
import com.cg.traineemanagement.beans.UserLogin;
import com.cg.traineemanagement.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	ITraineeDao dao;
	@Override
	public boolean login(UserLogin user) {
		// TODO Auto-generated method stub
		
		return dao.login(user);
	}
	@Override
	public void addDetails(TraineeBean bean) {
		// TODO Auto-generated method stub
		dao.addDetails(bean);
	}
	@Override
	public ArrayList<TraineeBean> getDeleteDetails(Integer traineeId) {
		// TODO Auto-generated method stub
		return dao.getDeleteDetails(traineeId);
	}
	@Override
	public void deleteDetails(TraineeBean bean) {
		// TODO Auto-generated method stub
		dao.deleteDetails(bean);
	}
	@Override
	public ArrayList<TraineeBean> getModifyDetails(Integer traineeId) {
		// TODO Auto-generated method stub
		return dao.getModifyDetails(traineeId);
	}
	@Override
	public void modifyDetails(TraineeBean bean) {
		dao.modifyDetails(bean);
		
	}
	@Override
	public ArrayList<TraineeBean> getAllDetails() {
		// TODO Auto-generated method stub
		return dao.getAllDetails();
	}

}
