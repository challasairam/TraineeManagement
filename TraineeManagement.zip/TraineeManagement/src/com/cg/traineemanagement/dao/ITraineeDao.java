package com.cg.traineemanagement.dao;

import java.util.ArrayList;

import com.cg.traineemanagement.beans.TraineeBean;
import com.cg.traineemanagement.beans.UserLogin;

public interface ITraineeDao {
	public boolean login(UserLogin user);

	public void addDetails(TraineeBean bean);

	public ArrayList<TraineeBean> getDeleteDetails(Integer traineeId);

	public void deleteDetails(TraineeBean bean);

	public ArrayList<TraineeBean> getModifyDetails(Integer traineeId);

	public void modifyDetails(TraineeBean bean);

	public ArrayList<TraineeBean> getAllDetails();
}
