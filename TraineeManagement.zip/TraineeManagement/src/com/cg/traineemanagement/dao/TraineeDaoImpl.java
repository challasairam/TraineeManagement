package com.cg.traineemanagement.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineemanagement.beans.TraineeBean;
import com.cg.traineemanagement.beans.UserLogin;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	EntityManager entityManager;
	@Override
	public boolean login(UserLogin user) {
		
		boolean result=false;
		Query query=entityManager.createNamedQuery("login");
		query.setParameter("user", user.getUserName());
		query.setParameter("pwd", user.getPassword());
		List<UserLogin> list=query.getResultList();
		if(!list.isEmpty())
		{
			result=true;
			
		}
		return result;
	}
	@Override
	public void addDetails(TraineeBean bean) {

		entityManager.persist(bean);
		entityManager.flush();
		
	}
	@Override
	public ArrayList<TraineeBean> getDeleteDetails(Integer traineeId) {
		Query query=entityManager.createNamedQuery("getDeleteDetails");
		query.setParameter("id", traineeId);
		ArrayList<TraineeBean> list=(ArrayList<TraineeBean>) query.getResultList();
		return list;
	}
	@Override
	public void deleteDetails(TraineeBean bean) {
		
	
		TraineeBean bean2=entityManager.find(TraineeBean.class,bean.getTraineeId());
		System.out.println(bean2);
		entityManager.remove(bean2);
		
		
	}
	@Override
	public ArrayList<TraineeBean> getModifyDetails(Integer traineeId) {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("getDeleteDetails");
		query.setParameter("id", traineeId);
		ArrayList<TraineeBean> list=(ArrayList<TraineeBean>) query.getResultList();
		return list;
	}
	@Override
	public void modifyDetails(TraineeBean bean) {
		// TODO Auto-generated method stub
		entityManager.merge(bean);
		entityManager.flush();
	}
	@Override
	public ArrayList<TraineeBean> getAllDetails() {
		// TODO Auto-generated method stub
		Query query=entityManager.createNamedQuery("getallDetails");
		ArrayList<TraineeBean> list=(ArrayList<TraineeBean>) query.getResultList();
		return list;
	}

}
