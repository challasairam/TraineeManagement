package com.cg.traineemanagement.controller;

import java.util.ArrayList;

import javax.faces.annotation.RequestMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineemanagement.beans.TraineeBean;
import com.cg.traineemanagement.beans.UserLogin;
import com.cg.traineemanagement.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService service;
	@RequestMapping("index")
	public ModelAndView getLoginPage()
	{
		ModelAndView view=new ModelAndView("login","login",new UserLogin());
		return view;
		
	}
	
	@RequestMapping("validatelogin")
	public ModelAndView validateLogin(@ModelAttribute("login") UserLogin login)
	{
		ModelAndView view=new ModelAndView();
		boolean result=service.login(login);
		if(result)
			view.setViewName("traineeHomePage");
		else
		{	
		view=new ModelAndView("login","login",new UserLogin());
		view.addObject("message","Enter valid credentials");
		}
		return view;
		
	}
	@RequestMapping("addTrainee")
	public ModelAndView getAddPage()
	{
		ModelAndView view=new ModelAndView("addTrainee","bean",new TraineeBean());
		ArrayList<String> locations=new ArrayList<>();
		locations.add("Chennai");
		locations.add("Bangalore");
		locations.add("Pune");
		locations.add("Mumbai");
		ArrayList<String> domain=new ArrayList<>();
		domain.add("JEE");
		domain.add(".Net");
		domain.add("Orapps");
		domain.add("VNV");
		view.addObject("locations",locations);
		view.addObject("domain",domain);
		return view;
		
	}
	
	@RequestMapping("insertDetails")
	public ModelAndView addDetails(@ModelAttribute("bean") TraineeBean bean)
	{
		service.addDetails(bean);
		ModelAndView view=new ModelAndView();
		view.setViewName("traineeHomePage");
		return view;
		
	}
	@RequestMapping("deleteTrainee")
	public ModelAndView getDeletePage()
	{
		ModelAndView view=new ModelAndView("deleteTrainee","bean",new TraineeBean());
		return view;
	}
	
	
	@RequestMapping("displaydetails")
	public ModelAndView getDeleteDetails(@ModelAttribute("bean") TraineeBean bean)
	{
		ArrayList<TraineeBean> list=service.getDeleteDetails(bean.getTraineeId());
		System.out.println(list);
		ModelAndView view=new ModelAndView("deleteTrainee","bean",new TraineeBean());
		view.addObject("list",list);
		return view;
	}
	
	@RequestMapping("delete")
	public ModelAndView deleteDetails(@ModelAttribute("bean") TraineeBean bean)
	{
		System.out.println(bean.getTraineeId());
		service.deleteDetails(bean);
		ModelAndView view=new ModelAndView();
		view.setViewName("traineeHomePage");
		return view;
	}
	
	
//	modifyTrainee
	
	@RequestMapping("modifyTrainee")
	public ModelAndView getModifyPage()
	{
		ModelAndView view=new ModelAndView("modifyTrainee","bean",new TraineeBean());
		return view;
	}
	
	
	@RequestMapping("displayModifydetails")
	public ModelAndView getModifyDetails(@ModelAttribute("bean") TraineeBean bean)
	{
		ArrayList<TraineeBean> list=service.getModifyDetails(bean.getTraineeId());
		System.out.println(list);
		ModelAndView view=new ModelAndView("modifyTrainee","bean",new TraineeBean());
		view.addObject("list",list);
		return view;
	}

	@RequestMapping("modify")
	public ModelAndView modifyDetails(@ModelAttribute("bean") TraineeBean bean)
	{
		System.out.println(bean.getTraineeId());
		service.modifyDetails(bean);
		ModelAndView view=new ModelAndView();
		view.setViewName("traineeHomePage");
		return view;
	}
	//retrieve
	
	//retrieveTrainee
	@RequestMapping("retrieveTrainee")
	public ModelAndView getRetrievePage()
	{
		ModelAndView view=new ModelAndView("retrieveTrainee","bean",new TraineeBean());
		return view;
	}
	
	
	@RequestMapping("displayretrievedetails")
	public ModelAndView getRetrievedDetails(@ModelAttribute("bean") TraineeBean bean)
	{
		ArrayList<TraineeBean> list=service.getDeleteDetails(bean.getTraineeId());
		System.out.println(list);
		ModelAndView view=new ModelAndView("retrieveTrainee","bean",new TraineeBean());
		view.addObject("list",list);
		return view;
	}
	//retrieve all
	//retrieveAllTrainees
	
	@RequestMapping("retrieveAllTrainees")
	public ModelAndView getAlldetails()
	{
		ArrayList<TraineeBean> list=service.getAllDetails();
		
		ModelAndView view=new ModelAndView("retrieveAllTrainee","bean",new TraineeBean());
		view.addObject("list",list);
		return view;
	}
	
}
